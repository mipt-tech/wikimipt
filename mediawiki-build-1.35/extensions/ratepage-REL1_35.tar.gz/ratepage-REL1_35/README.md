# RatePage
MediaWiki extension that enables users to rate pages on a wiki and set up contests.
More information and documentation: https://www.mediawiki.org/wiki/Extension:RatePage

The maintainer of this project is [Ostrzyciel](https://gitlab.com/Ostrzyciel).

## Contributing
Feel free to submit merge requests with new features or bug fixes. You can also take a look at [the list of open issues](https://gitlab.com/nonsensopedia/extensions/ratepage/-/issues). The localisation for this extension is done on [translatewiki.net](https://translatewiki.net/wiki/Special:Translate/mwgitlab-ratepage?group=mwgitlab-ratepage&language=pl&filter=%21translated&action=translate).
