<?php

$magicWords = [];

/** English
 * @author Ostrzyciel
 */
$magicWords['en'] = [ 'ratepage' => [ 0, 'ratepage' ] ];