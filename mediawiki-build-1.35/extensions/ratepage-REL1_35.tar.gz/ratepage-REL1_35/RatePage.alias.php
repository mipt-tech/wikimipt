<?php

$specialPageAliases = [];

/*
 *  English (English)
 */
$specialPageAliases['en'] = [
	'RatePageContests' => [ 'RatePageContests', 'RatePage_contests' ]
];

/*
 * Polish
 */
$specialPageAliases['pl'] = [
	'RatePageContests' => [ 'Konkursy_RatePage' ]
];
