ALTER TABLE /*_*/ratepage_vote MODIFY COLUMN rv_user varbinary(255);
ALTER TABLE /*_*/ratepage_vote MODIFY COLUMN rv_ip varbinary(255);
ALTER TABLE /*_*/ratepage_vote MODIFY COLUMN rv_contest varbinary(255);
