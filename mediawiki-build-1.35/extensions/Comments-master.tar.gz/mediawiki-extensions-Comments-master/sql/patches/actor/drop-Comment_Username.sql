ALTER TABLE /*_*/Comments DROP COLUMN Comment_Username;
