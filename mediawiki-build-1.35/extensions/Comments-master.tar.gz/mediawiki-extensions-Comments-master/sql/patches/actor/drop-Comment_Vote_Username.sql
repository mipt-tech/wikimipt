ALTER TABLE /*_*/Comments_Vote DROP COLUMN Comment_Vote_Username;
