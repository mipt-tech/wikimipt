ALTER TABLE /*_*/Comments_block ADD COLUMN cb_actor_blocked bigint unsigned NOT NULL AFTER cb_actor;
