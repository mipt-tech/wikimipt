CREATE INDEX /*i*/Comment_Vote_actor ON /*_*/Comments_Vote (Comment_Vote_actor);
