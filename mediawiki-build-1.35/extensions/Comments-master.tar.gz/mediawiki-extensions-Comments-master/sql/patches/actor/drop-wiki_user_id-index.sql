DROP INDEX /*i*/wiki_user_id ON /*_*/Comments;
