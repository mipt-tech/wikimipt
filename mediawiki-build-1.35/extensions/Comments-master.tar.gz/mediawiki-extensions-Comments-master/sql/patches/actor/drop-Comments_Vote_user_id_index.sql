DROP INDEX /*i*/Comments_Vote_user_id_index ON /*_*/Comments_Vote;
