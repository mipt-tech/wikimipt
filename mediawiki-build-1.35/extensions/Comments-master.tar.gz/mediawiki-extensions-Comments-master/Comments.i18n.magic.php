<?php
/**
 *  Magic words for extension.
 */

$magicWords = [];

/** English (English) */
$magicWords['en'] = [
	'NUMBEROFCOMMENTS' => [ 0, 'NUMBEROFCOMMENTS' ],
	'NUMBEROFCOMMENTSPAGE' => [ 0, 'NUMBEROFCOMMENTSPAGE' ],
];
